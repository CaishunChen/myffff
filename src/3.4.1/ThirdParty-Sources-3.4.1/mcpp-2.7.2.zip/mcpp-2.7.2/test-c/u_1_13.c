/* u_1_13.c:    Undefined behaviors on undefined #include syntax or header-
        name.   */

/* u.1.13:  Excessive argument in #include directive.   */
#include    <assert.h>  Junk

main( void)
{
    return  0;
}

