/* nest8.h  */

#ifndef X0F
    nest = 8;
#else
#include    "nest9.h"
#endif

