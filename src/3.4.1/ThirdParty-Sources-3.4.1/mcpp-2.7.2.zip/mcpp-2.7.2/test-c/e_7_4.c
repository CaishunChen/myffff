/* e_7_4.c:     #line error.    */

/* 7.4:     string literal in #line directive shall be a character string
        literal.    */

#line   123     L"wide"

main( void)
{
    return  0;
}

