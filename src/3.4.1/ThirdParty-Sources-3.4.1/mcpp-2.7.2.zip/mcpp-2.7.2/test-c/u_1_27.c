/* u_1_27.c:    Pseudo-directive-line.  */

/* u.1.27:  Unknown preprocessing directive (other than #pragma).   */
#ifdefined MACRO
#endif              /* The second error.    */

main( void)
{
    return  0;
}

