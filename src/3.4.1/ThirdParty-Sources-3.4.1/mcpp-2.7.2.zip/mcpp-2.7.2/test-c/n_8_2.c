/* n_8_2.c:     Argument of #error is optional. */

/* 8.2:     #error should be executed.  */
#error

