/* header.h */

#define MACRO_xyz   xyz
#define MACRO_zyx   zyx

