/* line.h   */

    __LINE__; __FILE__;
