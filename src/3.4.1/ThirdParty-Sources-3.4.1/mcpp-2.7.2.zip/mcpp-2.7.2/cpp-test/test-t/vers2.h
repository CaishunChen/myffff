/* vers2.h  */

/* comment */ # /**/ pragma /**/ once /**/

#include    <stdio.h>
#include    <limits.h>

/*
 * <stdio.h>, <limits.h> might have the line
 *      #pragma once
 * near the beginning.
 */
