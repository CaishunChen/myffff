/* l_37_8.c:    Translation limits larger than Standard / 8.    */

/* 37.8L:   Length of logical source line.  */
/*  Define one of the macros X03FF, X07FF, X0FFF, X1FFF or it will test
        the line of 0x3fff bytes long.  */
#include    "longline.c"

