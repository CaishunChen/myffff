/* most simple sample source to use libmcpp */

#include "mcpp_lib.h"

int
main (int argc, char *argv[])
{
    return mcpp_lib_main (argc, argv);
}
